export class Account {
    accountNo:number;
    password:number;
    name:String;
    balance:number;
constructor(accountNo:number,password:number,name:String,balance:number){
    this.accountNo=accountNo;
    this.password=password;
    this.name=name;
    this.balance=balance;
}

}
