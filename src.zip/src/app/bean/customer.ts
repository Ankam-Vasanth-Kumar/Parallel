

export class Customer {
    name:String;
    email:String;
    mobile:String;
    amount:number;
   
    address:String;

    constructor(name:String,email:string,mobile:string,amount:number,address:string){
        this.name=name;
        this.email=email;
        this.mobile=mobile;
        this.amount=amount;
        
        this.address=address;

    }
}
