import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/bean/customer';
import { Account } from 'src/app/bean/account';
import { BankService } from 'src/app/service/bank.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
acnt:Account;
amount:number;
message:string;
  constructor(private service:BankService) { }

  ngOnInit() {
  }
  deposit(acc:number,amount:number)
  {
  if(acc!=null)
  {
  this.acnt={"name":'',"accountNo":0,"password":0,"balance":amount};
  
  this.service.deposit(acc,this.acnt).subscribe(data=> {
    this.message='Amount deposited successfully'});
  alert("deposit successfull");
  }
  
  }
}
