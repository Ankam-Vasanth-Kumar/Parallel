import { Component, OnInit } from '@angular/core';
import { Transaction } from 'src/app/bean/transaction';
import { BankService } from 'src/app/service/bank.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {

  transaction:Transaction;
 constructor(private service:BankService) { }
 
 ngOnInit() {
 }
showTransaction(acc)
{
 if(acc!=null)
 {
 this.service.showTrans(acc).subscribe(data=>{this.transaction=data});
 
 }
else{
 alert("no such account present");
}
}
}


