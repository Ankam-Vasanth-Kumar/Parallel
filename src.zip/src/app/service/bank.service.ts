import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from '../bean/customer';
import { Account } from '../bean/account';
import { Observable } from 'rxjs';
import { Transaction } from '../bean/transaction';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  a
  private userUrl = 'http://localhost:5200';
  constructor(private http: HttpClient) { }
  public addCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.userUrl + '/addCustomer', customer);
  }
  public showBalance(acc: number) {
    console.log(acc);
    return this.http.get<Account>(this.userUrl + '/login/showbalance/' + acc);
  }
  public deposit(acc: number, accnt: Account): Observable<Account> {
    return this.http.put<Account>(this.userUrl + '/login/deposit/' + acc, accnt);
  }
  public withDraw(acc:number,accnt:Account):Observable<Account>
  {
  return this.http.put<Account>(this.userUrl+'/login/withdraw/'+acc,accnt);
  }
  public showTrans(acc:Number):Observable<Transaction>
{
 return this.http.get<Transaction>(this.userUrl+'/login/transactions/'+acc);
}
}
