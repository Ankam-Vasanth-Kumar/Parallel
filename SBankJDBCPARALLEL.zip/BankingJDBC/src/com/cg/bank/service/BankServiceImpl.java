package com.cg.bank.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;

import com.cg.bank.dao.BankDao;
import com.cg.bank.dao.BankDaoImpl;
import com.cg.bank.exception.BankException;

public class BankServiceImpl implements BankService {
BankDao bankDao=new BankDaoImpl();

	@Override
	public boolean ValidateName(String name) throws BankException {
		String pattern = "[A-Z]{1}[a-z]{4,}";
		boolean status = false;
		if (!Pattern.matches(pattern, name)) {
			status = false;
			throw new BankException(
					"Entered name should start with capital and should contain minimum  5 letters");
		} else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validateEmail(String email) throws BankException {
		String pattern = "[a-zA-Z0-9]{4,20}@gmail.com";
		boolean status = false;
		if (!Pattern.matches(pattern, email)) {
			status = false;
			throw new BankException("Invalid email ");
		}
		else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validatePhone(String phone) throws BankException {
		String pattern = "[7-9]{1}[0-9]{9}";
		boolean status = false;
		if (!Pattern.matches(pattern, phone)) {
			status = false;
			throw new BankException("Invalid phone");
		}
		else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validateAmount(double ammount) throws BankException {
		boolean status = false;
		if(ammount<5000)
		{
			status = false;
			throw new BankException("Minimum account balance shold be 5000");
		}
		else {
			status = true;
		}
		return status;
	}

	@Override
	public long getAccountNo() throws BankException {
		double generatedId = Math.random() * 10000000;
		long Id = (long) generatedId;
		return Id;
	}

	@Override
	public int getPassword() throws BankException {
		double generatedId = Math.random() * 10000;
		int Id = (int) generatedId;
		return Id;
	}

	@Override
	public boolean addAccount(Account account) throws BankException {
		
		return bankDao.addAccount(account);
	}

	@Override
	public boolean addCustomer(Customer customer) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.addCustomer(customer);
	}

	@Override
	public Account validLogin(String username, long password) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.validlogin(username,password);
	}

	@Override
	public boolean validateAmount1(double wAmount) throws BankException {
		boolean status=false;
		if(wAmount>10000)
			throw new BankException("Withdraw amount should be less than 10000");
		else
			status=true;
		return status;
	}

	@Override
	public boolean withDraw(double wAmount, Account acc) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.withDraw(wAmount,acc);
	}

	@Override
	public boolean addTransaction(BankTransaction transaction) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.addTransaction(transaction);
	}

	@Override
	public boolean deposit(double damount, Account acc) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.deposit(damount,acc);
	}

	@Override
	public List<BankTransaction> viewTransactions(Account acc) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.viewTransactions(acc);
	}

	@Override
	public double getBalance(Account account) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.getBalance(account);
	}

	@Override
	public int getTransId() throws BankException {
		// TODO Auto-generated method stub
		return bankDao.getTransId();
	}

	@Override
	public boolean fundTransfer(Account account, long accountNo, double tranferAmount) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.fundTransfer(account,accountNo,tranferAmount);
	}

}
