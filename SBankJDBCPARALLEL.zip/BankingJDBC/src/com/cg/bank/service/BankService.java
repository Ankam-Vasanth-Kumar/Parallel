package com.cg.bank.service;

import java.util.List;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;

import com.cg.bank.exception.BankException;

public interface BankService {

	boolean ValidateName(String name)throws BankException;

	boolean validateEmail(String email)throws BankException;

	boolean validatePhone(String phone)throws BankException;

	boolean validateAmount(double ammount)throws BankException;

	long getAccountNo()throws BankException;

	int getPassword()throws BankException;

	boolean addAccount(Account account)throws BankException;

	boolean addCustomer(Customer customer)throws BankException;

	Account validLogin(String username, long password)throws BankException;

	boolean validateAmount1(double wAmount)throws BankException;

	boolean withDraw(double wAmount, Account acc)throws BankException;

	boolean addTransaction(BankTransaction transaction)throws BankException;

	boolean deposit(double damount, Account acc)throws BankException;

	List<BankTransaction> viewTransactions(Account acc)throws BankException;

	double getBalance(Account account)throws BankException;

	int getTransId()throws BankException;

	boolean fundTransfer(Account account, long accountNo, double tranferAmount)throws BankException;

}
