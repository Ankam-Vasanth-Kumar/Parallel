package com.cg.bank.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static Connection connection=null;

	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			connection=DriverManager.getConnection(url, "vasanth", "vasanth");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return connection;
	}

}
