package com.cg.bank.presentation;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankService;
import com.cg.bank.service.BankServiceImpl;

public class MainUI {
	static Scanner scanner = new Scanner(System.in);
	static BankService service = new BankServiceImpl(); 
	public static void main(String[] args) {
		boolean continueFlag = false;
		do {

			System.out.println("****Welcome****");
			System.out.println("1.Create Account \n2.Login \n3.Exit");
			System.out.println("Enter choice:");
			try {
				int choice = scanner.nextInt();
				scanner.nextLine();
				switch (choice) {
				case 1:

					createAccount();

					break;
				case 2:
					boolean login = false;
					String userName=null;
					int password =0;
					do {
						
							System.out.println("Enter username: ");
							 userName = scanner.nextLine();
							System.out.println("Enter password: ");
							 password = scanner.nextInt();
							
						
							
						
						try {
							login(userName, password);
						} catch (BankException e) {
							System.out.println(e.getMessage());
							login = true;
							scanner.nextLine();
						}
					} while (login);
					break;
				case 3:
					System.out.println("***Thank You ***");
					System.exit(0);
					break;

				default:
					System.out.println("Enter 1,2,3");
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("Please Enter digits");
				continueFlag = true;
				scanner.nextLine();
			}
			String continueN = null;
			boolean cont = false;
			System.out.println("Do you want continue yes or No");
			do {

				continueN = scanner.next();
				if (continueN.equalsIgnoreCase("yes")) {
					continueFlag = true;
				} else if (continueN.equalsIgnoreCase("no")) {
					cont = false;
					continueFlag = false;
				} else {
					System.out.println("Please enter yes or no");
					cont = true;
				}
			} while (cont);
		} while (continueFlag);

	}
	public static void createAccount() {
		boolean status = false;
		String name = null;
		String email = null;
		String mobile = null;
		double amount = 0;
		long accountNo = 0;
		int password = 0;
		do {
			try {
				System.out.println("Enter name:");
				name = scanner.next();
				service.ValidateName(name);
				status = false;
			} catch (BankException e) {
				System.out.println(e.getMessage());
				status = true;
			}
		} while (status);
		do {
			try {
				System.out.println("Enter email:");
				email = scanner.next();
				service.validateEmail(email);
				status = false;

			} catch (BankException e) {
				System.out.println(e.getMessage());
				status = true;
			}
		} while (status);
		do {
			try {
				System.out.println("Enter phone:");
				mobile = scanner.next();
				service.validatePhone(mobile);
				status = false;

			} catch (BankException e) {
				System.out.println(e.getMessage());
				status = true;
			}
		} while (status);
		System.out.println("Enter address:");
		String address = scanner.next();
		do {
			try {
				System.out.println("Enter amount:");
				amount = scanner.nextDouble();
				service.validateAmount(amount);
				status = false;

			} catch (BankException e) {
				System.out.println(e.getMessage());
				status = true;
			}
		} while (status);
		try {
			accountNo = service.getAccountNo();
			password = service.getPassword();
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}

		Customer customer = new Customer(name, email, mobile, amount, accountNo, password, address);
		Account account = new Account(accountNo, password, name, amount);

		try {
			service.addCustomer(customer);
			service.addAccount(account);
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Account created with account number: " + accountNo + " and password: " + password);
	}
	public static boolean login(String userName, int password) throws BankException {
		Account account = service.validLogin(userName, password);
		Account account1 = new Account();
		account1 = account;
		
			if (account != null) {
				System.out.println("Login succesfull");
				boolean login = false;
				do {
					System.out.println("1. WithDraw \n2.Deposit \n3.Show Balance \n4.Fund Transfer \n5.Print Transactions");
					int choice = 0;
					try {
						choice = scanner.nextInt();
						switch (choice) {
						case 1:
							boolean amountFlag = false;
							do {
								double withDraw = 0;
								try {
									System.out.println("Enter amount: ");
									withDraw = scanner.nextDouble();
									service.withDraw(withDraw, account);
									
									Date date = new Date();
									java.sql.Date d1 = new java.sql.Date(date.getTime());
									int transaId = service.getTransId();
									BankTransaction transaction = new BankTransaction();
									transaction.setTransacId(transaId);
									transaction.setFromAccNo(account.getAccountNo());
									transaction.setToAccNo(account.getAccountNo());
									transaction.setTransacType("WithDraw");
									transaction.setDate(d1);
									transaction.setAmount(withDraw);
									transaction.setBalance(account.getAmount());
									service.addTransaction(transaction);
								} catch (BankException e) {
									System.out.println(e.getMessage());
									amountFlag = true;
									scanner.nextLine();
								}
							} while (amountFlag);
							break;
						case 2:
							boolean depositFlag = false;
							do {
								double depositAmount = 0;
								try {
									System.out.println("Enter amount: ");
									depositAmount = scanner.nextDouble();
									service.deposit(depositAmount, account);
									System.out.println("Amount Deposited successfully");
									Date date = new Date();
									java.sql.Date d1 = new java.sql.Date(date.getTime());
									int transaId = service.getTransId();
									BankTransaction transaction1 = new BankTransaction();
									transaction1.setTransacId(transaId);
									transaction1.setFromAccNo(account1.getAccountNo());
									transaction1.setToAccNo(account1.getAccountNo());
									transaction1.setTransacType("Deposit");
									transaction1.setDate(d1);
									transaction1.setAmount(depositAmount);
									transaction1.setBalance(account1.getAmount());
									service.addTransaction(transaction1);
								} catch (BankException e) {
									System.out.println(e.getMessage());
									depositFlag = true;
									scanner.nextLine();
								}
							} while (depositFlag);
							break;
						case 3:
							double amount = service.getBalance(account);
							System.out.println("Available amount: " + amount);
							break;
						case 5:
							List<BankTransaction> list=service.viewTransactions(account);
							for (BankTransaction bankTransaction : list) {
								System.out.println(bankTransaction);
							}
							break;
						case 4:
							try {
								System.out.println("Enter AccountNo: ");
								long accountNo=scanner.nextLong();
								System.out.println("Enter Amount: ");
								double tranferAmount=scanner.nextDouble();
								service.fundTransfer(account,accountNo,tranferAmount);
								int transaId = service.getTransId();
								Date date = new Date();
								java.sql.Date d1 = new java.sql.Date(date.getTime());
								BankTransaction transaction1 = new BankTransaction();
								transaction1.setTransacId(transaId);
								transaction1.setFromAccNo(account1.getAccountNo());
								transaction1.setToAccNo(accountNo);
								transaction1.setTransacType("Transfer");
								transaction1.setDate(d1);
								transaction1.setAmount(tranferAmount);
								transaction1.setBalance(account1.getAmount());
								service.addTransaction(transaction1);
							} catch (BankException e) {
								System.out.println(e.getMessage());
							}
							break;

						default:
							System.out.println("Enter digits 1,2,3,4");
							break;
						}
					} catch (InputMismatchException e) {
						System.err.println("Enter digits only");
						scanner.nextLine();
					}

					String continueN = null;
					boolean cont = false;
					System.out.println("Do you want continue yes or No");
					do {

						continueN = scanner.next();
						if (continueN.equalsIgnoreCase("yes")) {
							login = true;
						} else if (continueN.equalsIgnoreCase("no")) {
							cont = false;
							login = false;
						} else {
							System.out.println("Please enter yes or no");
							cont = true;
						}
					} while (cont);

				} while (login);
				return true;	}
			
			else
			throw new BankException("Invalid login");
		

		}

}
