package com.cg.bank.dao;

import java.util.List;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;

import com.cg.bank.exception.BankException;

public interface BankDao {

	boolean addAccount(Account account)throws BankException;

	boolean addCustomer(Customer customer)throws BankException;

	Account validlogin(String username, long password)throws BankException;

	boolean withDraw(double wAmount, Account acc)throws BankException;

	boolean addTransaction(BankTransaction transaction)throws BankException;

	boolean deposit(double damount, Account acc)throws BankException;

	List<BankTransaction> viewTransactions(Account acc)throws BankException;

	double getBalance(Account account)throws BankException;

	int getTransId()throws BankException;

	boolean fundTransfer(Account account, long accountNo, double tranferAmount)throws BankException;

	

}
