package com.cg.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;

import com.cg.bank.connection.DBConnection;
import com.cg.bank.exception.BankException;

public class BankDaoImpl implements BankDao {
	PreparedStatement statement = null;
	int row = -1;
	

	@Override
	public boolean addAccount(Account account) throws BankException {
		boolean validate = false;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select accountseq.NEXTVAL from dual");
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				validate = true;
				statement = connection.prepareStatement("insert into account values(?,?,?,?)");
				statement.setString(3, account.getName());
				statement.setDouble(4, account.getAmount());
				statement.setLong(1, account.getAccountNo());
				statement.setInt(2, account.getPassword());
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return validate;
	}

	@Override
	public boolean addCustomer(Customer customer) throws BankException {
		boolean validate = false;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select custseq.NEXTVAL from dual");
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				validate = true;
				statement = connection.prepareStatement("insert into customer values(?,?,?,?,?,?)");
				statement.setLong(7, customer.getAccountNo());
				statement.setString(1, customer.getName());
				statement.setString(2, customer.getEmail());
				statement.setString(3, customer.getMobile());
				statement.setString(6, customer.getAddress());
				statement.setDouble(4, customer.getAmount());
				statement.setInt(5, customer.getPassword());
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return validate;
	}

	@Override
	public Account validlogin(String username, long password) throws BankException {
		Account account1 = new Account();
		try (Connection connection = DBConnection.getConnection();) {
		 
			statement = connection.prepareStatement("select*from account where NAME=? and PASSWORD=?");
			statement.setString(1, username);
			statement.setLong(2, password);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				System.out.println(resultSet.getString("NAME"));
				account1.setName(resultSet.getString("NAME"));
				account1.setAccountNo(resultSet.getLong("ACCOUNTNO"));
				account1.setAmount(resultSet.getDouble("amount"));
				account1.setPassword(resultSet.getInt("PASSWORD"));
			}
			else {
				throw new BankException("username and password not exists");
			}
		} catch (SQLException e1) {
			System.err.println(e1.getMessage());
		}

		return account1;
	}

	@Override
	public boolean withDraw(double wAmount, Account acc) throws BankException {
		boolean status = false;
		double amount = acc.getAmount();
		int password = acc.getPassword();
		
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select amount from account where PASSWORD=?");
			statement.setInt(1, password);

			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				System.out.println("balace in table" + rs.getDouble("amount"));
				if (rs.getDouble("amount") < wAmount) {
					System.err.println("Insufficient Fund");
					status = false;
				}

				else {amount = amount - wAmount;
				acc.setAmount(amount);
					statement = connection.prepareStatement("update account set amount=? where PASSWORD=?");
					statement.setInt(2, password);
					statement.setDouble(1, amount);
					row = statement.executeUpdate();
					System.out.println("Amount withdrawn successfully");
					status = true;
				}
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return status;

	}

	@Override
	public boolean addTransaction(BankTransaction transaction) throws BankException {
		boolean status = false;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select transacseq.NEXTVAL from dual");
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				status = true;
				statement = connection.prepareStatement("insert into transaction1 values(?,?,?,?,?,?,?)");
				statement.setInt(1, transaction.getTransacId());
				statement.setLong(2, transaction.getToAccNo());
				statement.setLong(3, transaction.getFromAccNo());
				statement.setString(4, transaction.getTransacType());
				Date date = new Date(transaction.getDate().getTime());
				statement.setDate(5, date);
				statement.setDouble(6, transaction.getAmount());
				statement.setDouble(7, transaction.getBalance());

				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return status;
	}

	@Override
	public boolean deposit(double damount, Account acc) throws BankException {
		boolean status = false;
		double amount = acc.getAmount();
		int password = acc.getPassword();
		amount = amount + damount;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("update account set amount=? where PASSWORD=?");
			statement.setInt(2, password);
			statement.setDouble(1, amount);
			row = statement.executeUpdate();
			status = true;

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return status;
	}

	@Override
	public List<BankTransaction> viewTransactions(Account acc) throws BankException {
		List<BankTransaction> list1 = new ArrayList<>();
		BankTransaction transaction = new BankTransaction();
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select*from transaction1 where FromAccNo=?");

			statement.setLong(1, acc.getAccountNo());
			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				transaction.setTransacId(resultSet.getInt("transacId"));
				transaction.setTransacType(resultSet.getString("TransacType"));
				transaction.setDate(resultSet.getDate("date1"));
				transaction.setToAccNo(resultSet.getLong("toAccNo"));
				transaction.setFromAccNo(resultSet.getLong("FromAccNo"));
				transaction.setAmount(resultSet.getDouble("amount"));
				transaction.setBalance(resultSet.getDouble("balance"));

				System.out.println(transaction);

			}

		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

		return list1;
	}

	@Override
	public double getBalance(Account account) throws BankException {
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("select amount from account where PASSWORD=?");
			statement.setInt(1, account.getPassword());

			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				return rs.getDouble("amount");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int getTransId() throws BankException {
		Random r =new Random();
		int transId=r.nextInt();
		return transId;
	}

	@Override
	public boolean fundTransfer(Account account, long accountNo, double tranferAmount) throws BankException {
		double prevBal;
		double amount;
		double amount1;
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select amount from account  where accountNo=?");
			statement.setLong(1, account.getAccountNo());
			ResultSet rs = statement.executeQuery();
			if(rs.next()) {
			prevBal = rs.getDouble(1);
			if (prevBal >= tranferAmount) {
				
				statement = connection.prepareStatement("select amount from account  where accountNo=?");
				statement.setLong(1, accountNo);
				ResultSet rs11 = statement.executeQuery();
				if(rs11.next()) {
					amount = prevBal - tranferAmount;
					System.out.println(" account   current bal :" + amount);
					statement = connection.prepareStatement("update account set amount=? where accountNo=?");
					statement.setDouble(1, amount);
					statement.setLong(2, account.getAccountNo());
					statement.executeUpdate();
				prevBal = rs11.getLong(1);
				amount1 = tranferAmount + prevBal;
				System.out.println("prev bal:" + prevBal);
				System.out.println("current bal :" + amount1);
				statement = connection.prepareStatement("update account set amount=? where accountNo=?");
				statement.setDouble(1, amount1);
				statement.setLong(2, accountNo);
				row = statement.executeUpdate();}
				else {
					throw new BankException(" account Not found");
				}

			}
			else
				throw new BankException("Insufficient Fund");
		}
			else
				throw new BankException("No account number present");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

}
