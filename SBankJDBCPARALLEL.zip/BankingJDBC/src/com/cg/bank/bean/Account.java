package com.cg.bank.bean;





public class Account {
	
	private long accountNo;
	private int password;
	private String name;
	private double amount;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNo, int password, String name, double amount) {
		super();
		this.accountNo = accountNo;
		this.password = password;
		this.name = name;
		this.amount = amount;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", password=" + password + ", name=" + name + ", amount=" + amount
				+ "]";
	}
	

}
