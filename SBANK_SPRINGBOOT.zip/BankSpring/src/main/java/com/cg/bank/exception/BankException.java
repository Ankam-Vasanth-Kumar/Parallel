package com.cg.bank.exception;

public class BankException extends Exception {

	public BankException() {
		super();
		
	}

	public BankException(String arg0) {
		super(arg0);
		
	}
	

}
