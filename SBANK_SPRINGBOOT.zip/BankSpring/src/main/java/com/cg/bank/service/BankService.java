package com.cg.bank.service;

import java.util.List;

import com.cg.bank.dto.Account;
import com.cg.bank.dto.Customer;
import com.cg.bank.dto.Transaction;
import com.cg.bank.exception.BankException;

public interface BankService {

	String addCustomer(Customer customer)throws BankException;

	String login(Account account)throws BankException;

	String withdraw(long accountNo, Account account)throws BankException;

	 Account showBalance(long accountNo)throws BankException;

	String depositAmount(long accountNo, Account account)throws BankException;

	String fundTransfer(double amount, long accountNo, Account account)throws BankException;

	List<Transaction> printTransaction(long accountNo)throws BankException;

}
