package com.cg.bank.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "BankTransaction")
public class Transaction {
	@Id
	@SequenceGenerator(name = "transSeq", sequenceName = "transSeq",initialValue = 8765,allocationSize = 3)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "transSeq")
	private int transId;
	private String transType;
	private Date transDate;
	private long fromAccountNo;
	private long toAccountNo;
	private double amount;
	private double balance;

	public Transaction(String string, Date d, long l, long m, double amount2, double amnt) {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transId, String transType, Date transDate, long fromAccountNo, long toAccountNo, double amount,
			double balance) {
		super();
		this.transId = transId;
		this.transType = transType;
		this.transDate = transDate;
		this.fromAccountNo = fromAccountNo;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
		this.balance = balance;
		
	}
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public long getfromAccountNo() {
		return fromAccountNo;
	}
	public void setfromAccountNo(long fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}
	public long gettoAccountNo() {
		return toAccountNo;
	}
	public void settoAccountNo(long toAccountNo) {
		this.toAccountNo = toAccountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", transType=" + transType + ", transDate=" + transDate
				+ ", customerid=" + fromAccountNo + ", accountNo=" + toAccountNo + ", amount=" + amount + ", balance="
				+ balance + ", transactionlsit=" + "]";
	}
	
	


}
