package com.cg.bank.service;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.BankTransaction;
import com.cg.bank.bean.Customer;
import com.cg.bank.exception.BankException;

public interface BankService {

	boolean validateName(String name)throws BankException;

	boolean validateEmail(String email)throws BankException;

	boolean validateMobile(String mobile)throws BankException;

	long getAccountNo()throws BankException;

	boolean validateAmount(double amount)throws BankException;

	int getPassword()throws BankException;

	boolean addCustomer(Customer customer)throws BankException;

	boolean addAcount(Account account)throws BankException;

	Account validateLogin(String userName, int password)throws BankException;

	boolean withdraw(double withDraw,Account account)throws BankException;

	boolean deposit(double depositAmount,Account account)throws BankException;

	double getBalance(Account account)throws BankException;

	boolean printTransactions(Account account)throws BankException;

	int getTransId()throws BankException;

	boolean addTransaction(BankTransaction transaction)throws BankException;

	boolean fundTransfer(Account account, long accountNo, double tranferAmount)throws BankException;

}
